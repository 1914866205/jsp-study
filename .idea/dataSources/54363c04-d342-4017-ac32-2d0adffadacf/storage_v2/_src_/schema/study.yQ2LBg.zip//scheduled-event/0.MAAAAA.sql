create definer = jsp@`%` event `0` on schedule
    at '2022-03-09 16:00:56'
    enable
    do
    SELECT * FROM person;

